package com.example.flutter_application_sqflite

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
